/*! @file PicParams.h 

  @brief PicParams.h is the class that hold the simulation parameters and can read from a file the namelist

  @author tommaso vinci
  @date 2013-02-15
*/

#ifndef PICPARAMS_h
#define PICPARAMS_h

#include <vector>
#include <string>

//**********************************************************************************************************************
//! This structure contains the properties of each species
struct LaserStructure {
	//! Laser field amplitude
	double a0;

	//! Laser angle
	double angle;

	//! Laser delta (ellipticity parameter)
	double delta;
	
	//! Laser profile
	std::string time_profile;
	
	//! int vector for laser parameters
	std::vector<int> int_params;
	
	//! double vector for laser parameters
	std::vector<double> double_params;
};

//**********************************************************************************************************************
//! This structure contains the properties of each species
struct SpeciesStructure {
	//! kind of species possible values: "ion" "electron" "test"
	std::string species_type;
    
    //! initialization type. Possible values: "regular" "cold" "Maxwell-Juettner"
	std::string initialization_type;
	
	//! number of particles per cell
	unsigned int n_part_per_cell;
	
    //! coefficient on the maximum number of particles for the species
	double c_part_max;
    
    //! maximum number of particles for the species
    unsigned int n_part_max;
    
	//! mass [electron mass]
	double mass;
	
	//! charge [proton charge]
	double charge;
	
    //! density [\f$n_N=\epsilon_0\,m_e\,\omega_N^{2}/e^2\f$ ]
	double density;
	//! mean velocity in units of light velocity
	std::vector<double> mean_velocity; // must be params.nDim_field
	//! temperature [\f$m_e\,c^2\f$ ]
	std::vector<double> temperature;
	
	//! dynamics type. Possible values: "Norm" "Radiation Reaction"
	std::string dynamics_type;
	
	//! Time for which the species is frozen
	double time_frozen;
	
	//! logical true if particles radiate
	bool radiating;

	//! Boundary conditions for particules
	std::string bc_part_type;

};

//**********************************************************************************************************************
//! PicParams class: this holds all the properties of the simulation that are read from the input file
//
class PicParams {
	
public:
	PicParams(std::string);

	void parseFile(std::string);
	void print();

	/*******************************************************************************************************************
	 Variable declaration
	 ******************************************************************************************************************/
	
	//! defines the geometry of the simulation
	std::string geometry;

	//! defines the interpolation/projection order
	unsigned int interpolation_order;

	//! number of space dimensions for the particles
	unsigned int nDim_particle;

	//! number of space dimensions for the fields
	unsigned int nDim_field;
	
	/*! \brief Time resolution.
	Number of timesteps in \f$ 2\pi/\omega_N \f$ where \f$ \omega_N \f$ is the normalization (plasma or laser) frequency 
	*/
	unsigned int res_time;
	
	//! simulation exit time in units of \f$ 2\pi/\omega_N \f$
	double sim_time;

	/*! \brief Space resolution.
	Number of cells in every direction in \f$ 2\pi/k_N \f$ where \f$ k_N=\omega_N/c \f$ is the normalization wavenumber
	*/
	std::vector<unsigned int> res_space;

	//! simulation box size in \f$2\pi/k_N \f$
	std::vector<double> sim_length;

	//! plasma geometry
	std::string plasma_geometry;

	//! plasma lengths 
	std::vector<double> plasma_length;

	//! vacuum lengths 
	std::vector<double> vacuum_length;
	
	//! initial number of species
	unsigned int n_species;

	//! parameters of the species
	std::vector<SpeciesStructure> species_param;

	//! initial number of particles
	unsigned int n_particles;

	//! number of total timesteps to perform in the simulation
	unsigned int n_time;
	
	//! dt for the simulation (CFL)
	double timestep;

	//! number of cells in every direction
	std::vector<unsigned int> n_space;
	
	//! spatial step (cell dimension in every direction)
	std::vector<double> cell_length;
	
	//! volume of cell (this will be removed by untructured mesh!)
	double cell_volume;
	
	//! wavelength
	double wavelength;
	
	//! physicist (cgs with temperatures in eV) theorist
	std::string sim_units;
	
	
	//! initial number of laser pulses
	unsigned int n_laser;
	
	//! laser parameters
	std::vector<LaserStructure> laser_param;
	
	
};

#endif

