Releases
--------

Major releases are available here as well as on the
`GitHub page <https://github.com/SmileiPIC/Smilei>`_.
For an access to the `developer's Gitlab repository <https://llrgit.in2p3.fr/smilei/smilei>`_,
you will need to ask for a password first, but the process is fast and straightforward.

----

Future release 3.0
^^^^^^^^^^^^^^^^^^

In progress ...

Major improvements:

* 3D geometry


----

.. _latestVersion:

Current release 2.3
^^^^^^^^^^^^^^^^^^^

**Download**: `Smilei v2.3 <_downloads/smilei-v2.3.tar.gz>`_

Major improvements:

* **state-of-the-art** dynamic load balancing
* full *python* namelist, allowing for complex, user-friendly input
* external fields and antennas
* binary Coulomb collisions
* new diagnostics
* *python* scripts for post-processing

We greatly appreciate external users trying this code and giving feedback.
You can :doc:`contact us <partners>` to become a developer of the official releases.


----

Release 1.0
^^^^^^^^^^^

**Download**: `Smilei v1.0 <_downloads/smilei-v1.0.tar.gz>`_

After nearly two years of development, :program:`Smilei` v1.0 offers some nice features:

* 1D & 2D cartesian geometries
* moving-window
* hybrid MPI-OpenMP parallelization
* field ionization
* some python diagnostics
* open-source

.. warning::
  This version does not have associated documentation.
  Please refer to the examples.


